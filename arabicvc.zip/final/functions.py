import os,sys,shutil,numpy,arabic_reshaper 
from random import SystemRandom
from bidi.algorithm import get_display 
from pathlib import Path
from PIL import Image, ImageFont, ImageDraw, ImageFilter, ImageChops
import PIL.ImageOps	

def findlocation():
	location=os.getcwd()
	return location
	
def deleteallfiles(folder):
	for filename in os.listdir(folder):
		file_path = os.path.join(folder, filename)
		try:
			if os.path.isfile(file_path) or os.path.islink(file_path):
				os.unlink(file_path)
			elif os.path.isdir(file_path):
				shutil.rmtree(file_path)
		except Exception as e:
			print('Failed to delete %s. Reason: %s' % (file_path, e))

def resetfiles(location):
	Path(location+"/output").mkdir(parents=True, exist_ok=True)
	deleteallfiles(location+'/output')
	deleteallfiles(location+"/upload/")
	Path(location+"/upload").mkdir(parents=True, exist_ok=True)
	Path(location+'/output/arabictext').mkdir(parents=True, exist_ok=True)
	Path(location+'/output/decryptedimages').mkdir(parents=True, exist_ok=True)
	Path(location+'/output/share').mkdir(parents=True, exist_ok=True)
	Path(location+"/upload").mkdir(parents=True, exist_ok=True)
	os.chdir(location)

def whitetotransparent(share):
	newData = []
	share = share.convert("RGBA")
	datas = share.getdata()
	for item in datas:
		if item[0] == 255 and item[1] == 255 and item[2] == 255:
			newData.append((255, 255, 255, 0))
		else:
			newData.append(item)
	share.putdata(newData)
	return share

def makeshare(infile,location):
	os.chdir(location+'/output/arabictext')
	img = Image.open(infile)
	img=img.convert('1')
	width=img.size[0]*2
	height=img.size[1]*2
	share1 = Image.new('1', (width, height))
	share2 = Image.new('1', (width, height))
	draws1 = ImageDraw.Draw(share1)
	draws2 = ImageDraw.Draw(share2)
	patterns=((1,1,0,0), (1,0,1,0), (1,0,0,1), (0,1,1,0), (0,1,0,1), (0,0,1,1))
	for x in range(0, int(width/2)):
		for y in range(0, int(height/2)):
			pixel=img.getpixel((x,y))
			random = SystemRandom()
					#pattern drawn for share 1
			pat=random.choice(patterns)
			draws1.point((x*2, y*2), pat[0]) 
			draws1.point((x*2+1, y*2), pat[1])
			draws1.point((x*2, y*2+1), pat[2])
			draws1.point((x*2+1, y*2+1), pat[3])
			if pixel==0:	#Dark pixel so share 2 gets the anti pattern	
				draws2.point((x*2, y*2), 1-pat[0])	
				draws2.point((x*2+1, y*2), 1-pat[1])
				draws2.point((x*2, y*2+1), 1-pat[2])
				draws2.point((x*2+1, y*2+1), 1-pat[3])		
			else:		#Light pixel so share 2 gets the same pattern	
				draws2.point((x*2, y*2), pat[0])
				draws2.point((x*2+1, y*2), pat[1])
				draws2.point((x*2, y*2+1), pat[2])
				draws2.point((x*2+1, y*2+1), pat[3])			
	return share1,share2			

def decrypt(share1,share2,gap,M,location):
	w, h = ( 400, 120)
	width=400
	height=(120+gap)*M
	y1=height-120
	y2=0
	for i in range(0,M):
		patternbox1 = (0,y1+gap,width,y1+120)		#( x, y, x + width , y + height )
		patternbox2 = (0,y2+gap,width,y2+120)
		a=share1.crop(patternbox1)
		b=share2.crop(patternbox2)
		decode=overlap(a,b)
		y1=y1-(gap+120)
		y2=y2+(gap+120)
		decode.save(location+"/output/decryptedimages/decrypt"+str(i)+".png",optimize=True,quality=97)

def modifiedmakeshare(gap,M,location):				
	os.chdir(location+'/output/arabictext')
	width=400
	height=(120+gap)*M
	share1 = Image.new('1', (width, height),"white")
	share2 = Image.new('1', (width, height),"white")
	share1=whitetotransparent(share1)
	share2=whitetotransparent(share2)
	draws1 = ImageDraw.Draw(share1)
	draws2 = ImageDraw.Draw(share2)
	A=[]
	B=[]
	for i in range(0,M):	
		A.append(0)
		B.append(0)
		arabictext="arabtext"+str(i)+".png"
		A[i],B[i]=makeshare(arabictext,location)
		y1=height-120
		y2=0
	for i in range(0,M):
		share1.paste(A[i],(0,y1))
		share2.paste(B[i],(0,y2))
		y1=y1-gap
		y2=y2+120
		random1,random2=randomize(gap,location)
		share1.paste(random1,(0,y1))
		share2.paste(random2,(0,y2))
		y1=y1-120
		y2=y2+gap
		

		
	share1.save(location+"/output/share/share1.png",optimize=True,quality=97)
	share2.save(location+"/output/share/share2.png",optimize=True,quality=97)
	
def arabtexttoimg(text,i,location):
	reshaped_text = arabic_reshaper.reshape(text)
	bidi_text = get_display(reshaped_text)
	encode = Image.new('1',(200,60), "WHITE")
	font = ImageFont.truetype(location+"/Sahel.ttf", size=35)
	draw = ImageDraw.Draw(encode)
	draw.multiline_text((19,5), bidi_text, font=font, fill='black', spacing=15, align="right")
	encode.save(location+"/output/arabictext/arabtext"+str(i)+".png",optimize=True,quality=97)
	
def overlap(a,b):
	width=a.size[0]
	height=a.size[1]
	new = Image.new('1', (width, height))
	draws= ImageDraw.Draw(new)
	for x in range(0, int(width)):
		for y in range(0, int(height)):
			if (a.getpixel((x,y))==b.getpixel((x,y))):
				draws.point((x, y),1)	
	return new
			
def randomize(gap,location):
	imarray = numpy.random.rand(gap,400,3) * 255
	im = Image.fromarray(imarray.astype('uint8')).convert('L')
	im.save("random.png")
	x,y=makeshare("random.png",location)
	os.remove("random.png")
	return x,y	
		
def decryptzip(source, destination):
        base = os.path.basename(destination)
        name = base.split('.')[0]
        format = base.split('.')[1]
        archive_from = os.path.dirname(source)
        archive_to = os.path.basename(source.strip(os.sep))
        shutil.make_archive(name, format, archive_from, archive_to)
        shutil.move('%s.%s'%(name,format), destination)	
