
#from arabicvc.functions.arabicvc import setup
from datetime import datetime
from flask import render_template
from UI import app
from flask import request
import random
import os
from flask import Flask, flash, request, redirect, url_for
from flask import send_file, send_from_directory, safe_join, abort
from random import SystemRandom
import threading
import subprocess
import time

location=os.getcwd()

def run(process,M=0,secrettext=''):
	
	if process=="reset":
		execute="python3 arabicvc.py reset"
		subprocess.call(execute, shell=True)
	if process=="encrypt":
		execute="python3 arabicvc.py encrypt "+str(M)+" "+secrettext
		subprocess.call(execute, shell=True)
	if process=="decrypt":
		execute="python3 arabicvc.py decrypt "+str(M)
		subprocess.call(execute, shell=True)



@app.route('/')
@app.route('/home')
def home():
	run("reset")
	return render_template(
		'index.html',
		title='Home Page',
		year=datetime.now().year,
	)



@app.route('/encrypt')
def encrypt():
	return render_template(
		'encrypt.html',
		title='Encrypt',
		 
		message='ENTER THE ARABIC TEXT'
	)



    

@app.route('/encryptdone', methods = ['POST'])  
def encryptdone():  
	if request.method == 'POST':  
		M=int(request.form.get('n'))
		secrettext=request.form.get('secretarray')
		run("encrypt",M,secrettext)
		return render_template('encryptdone.html',
			title='Success',
			year=datetime.now().year,
			message='These are your Share Images')

@app.route('/decrypt')
def decrypt():
	return render_template(
		'decrypt.html',
		title='Decrypt',
		year=datetime.now().year,
		message='Upload your encrypted image along with the key'
	)
	

@app.route('/decryptdone', methods = ['POST'])  
def decryptdone():  
	if request.method == 'POST':  
		s1= request.files['share1']  
		s2= request.files['share2']  
		s1.save(location+"/upload/share1.png")
		s2.save(location+"/upload/share2.png")
		M=int(request.form.get('n'))
		run("decrypt",M)
		return render_template('decryptdone.html',
		title='Decrypted',
		year=datetime.now().year,
		message='These are your Decrypted Images')


@app.route('/return-file')
def return_file():
	try:
		
		return send_file(location+"/output/decryptedimages.zip")
	except Exception as e:
		return str(e)
	
	
		
	
@app.route('/return-share1')
def return_share1():
	try:
		return send_file(location+"/output/share/share1.png", mimetype='image/png')
	except Exception as e:
		return str(e)
	
	
	
@app.route('/return-share2')
def return_share2():
	try:
		return send_file(location+"/output/share/share2.png", mimetype='image/png')
	except Exception as e:
		return str(e)
	
									
									
									
									

	
	


