from time import sleep
from random import SystemRandom
from functions import *
import os.path
import os
os.system('clear')

location=findlocation()
if sys.argv[1]=="reset":								#python3 arabicvc.py reset
	resetfiles(location)
	exit()

random = SystemRandom()
gap=random.choice([1,2,3,4,5,6,7,8,9,0])
secrets=int(sys.argv[2])

if sys.argv[1]=="encrypt":								#python3 arabicvc.py encrypt 3 دجاجة,الثعلب,نجمة,القرآن,سر,سر
	resetfiles(location)
	text=sys.argv[3].split(',')
	for i in range(0,secrets):
		arabtexttoimg(text[i],i,location)
	modifiedmakeshare(gap,secrets,location)
	os.system('clear')
	print("\n\n\n\n\n\n\n\n\n\tENCRYPTION DONE")
	sleep(0.5)
	os.system('clear')
	exit()
	
	
if sys.argv[1]=="decrypt":	
	if os.path.isfile(location+"/upload/share1.png") and os.path.isfile(location+"/upload/share2.png"):	#python3 arabicvc.py decrypt 3
		share1= Image.open(location+"/upload/share1.png")
		share2= Image.open(location+"/upload/share2.png")
	else:
		nas=input("TYPE UPLOAD TO UPLOAD THE SHARES\n\n\t")
		if nas=="UPLOAD" or nas=="upload" :
			share1= Image.open(location+"/output/share/share1.png")
			share2= Image.open(location+"/output/share/share2.png")
		else:
			os.system('clear')
			print("\n\n\n\n\n\n\n\n\n\tSHARE NOT FOUND")
			sleep(0.5)
			os.system('clear')
			exit()
		
	gap=int((share1.size[1]/secrets)-120)
	decrypt(share1,share2,gap,secrets,location)
	decryptzip(location+"/output/decryptedimages", location+"/output/decryptedimages.zip")
	os.system('clear')
	print("\n\n\n\n\n\n\n\n\n\tDECRYPTION DONE")
	sleep(0.5)
	os.system('clear')
	exit()
